package com.example.sample.chatting.model;



public class Message{
    public String idSender;
    public String idReceiver;
    public String text;
    public String imgUrl;
    public long timestamp;

}