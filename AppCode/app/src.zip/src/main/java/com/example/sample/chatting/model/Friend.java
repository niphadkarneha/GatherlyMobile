package com.example.sample.chatting.model;



public class Friend extends User{
    public String id;
    public String idRoom;
}
